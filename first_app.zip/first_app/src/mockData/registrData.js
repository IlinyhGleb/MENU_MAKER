export const registrTittle = {
    text: "Форма регистрации",
    href: "#",
  };

export const elements = [
    {   
        label: "Фамилия",
		type: "input",
        title: "В", 				
     },
     {   
        label: "Имя",
		type: "input", 	
        title: "В", 			
     },
     {   
        label: "E-mail",
		type: "input",
        title: "В",  				
     },
     {   
        label: "Пароль",
		type: "input",
        title: "В",  				
     },
     {   
        label: "Проверка пароля",
		type: "input", 				
        title: "В", 
     },
     {
        type: "button",
        title: "Зарегистрировать",
     }
 ];

 export const registrButton= {

 }

 export const registrData = {
    registrTittle,
    elements
  };
