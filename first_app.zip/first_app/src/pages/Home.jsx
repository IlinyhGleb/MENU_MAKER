import {Header} from "../components/Header";
import {Hero} from "../components/Hero";
const Home = () => {
  return (
    <>
      <section className="section header">
        <Header />
      </section>  
      <section className="section hero_section">
        <Hero />
      </section>
    </>
  );
};

export {Home};
