import { useState, useEffect } from "react";
import {Link} from "react-router-dom";
import beginMenuData from "../mockData/beginMenuData";
import { MenuItemTemplate } from "./Header";


export const HeaderTemplate = ({headerData}) => {
    const {text} = headerData;
    return (<h3>{text}</h3>)
};

export const ButtonTemplate = ({ beginButton }) => {
    const {title, href, isPrimary} = beginButton;
    return (
      <Link to={href}> 
       <button className={`cta_buttons__signin btn${isPrimary ? " primary-btn" : ""}`}>
        {title}
       </button>
      </Link>
    );
 };   

 export const productTemplate = ({products}) => {
    const {data, gr} = products;
    return ( 
    <div>
        <div className="products">
            {data}
        </div>
        <div className="gr">
        {gr}
    </div>
    </div>
    );
 }

 export const menuTemplate = ({menuData}) => {
    const {title, products} = menuData;
    return (
        <div className="menuData">
            <div className="menuTitle">
            {title}
            </div>
            <div className="menuTitle">
            <template products = {products}/>
            </div>
        </div>
    );
 }

 export const template = ({products}) => {
    return  products.map((data, gr, index) => (
        <productTemplate key ={index} data={data} gr={gr} />
        ))
 }


const BeginMenu = () => {
    const {
        headerData, 
        beginButton, 
        breakfastData,
        lunchData,
        dinnerData,
        breakData,
    } = beginMenuData

    return (
        <>
        <div className="hero_section__left">
        <HeaderTemplate headerData = {headerData} />     
        <ButtonTemplate beginButton = { beginButton } />
        <menuTemplate menuData = {breakfastData} />
        <menuTemplate menuData = {lunchData} />
        <menuTemplate menuData = {dinnerData} />
        <menuTemplate menuData = {breakData} />
        </div>
        </>
      );
};

export {BeginMenu};