import {Routes, Route, Link} from 'react-router-dom';

import {Home} from "./pages/Home";
import {Registr} from "./pages/Registr";
import {Begin} from "./pages/Begin";

function App() {
  return (
    <>
    
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/registration" element={<Registr/>}/>
      <Route path="/beginMenu" element={<Begin/>}/>

   </Routes>
    </>
    

  );
}

export default App;
