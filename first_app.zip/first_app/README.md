# Установка проекта (должен быть установлен nodejs)
npm i
npm install react-router-dom

# Запуск проекта в режиме разработки
npm run start

# Сборка проекта
npm run build
